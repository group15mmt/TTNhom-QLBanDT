﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace N35_WebBanDT.Controllers
{
    public class LienHeController : Controller
    {
        // GET: LienHe
        public ActionResult GioiThieu()
        {
            return View();
        }
        public ActionResult TinTuc()
        {
            return View();
        }
        public ActionResult LienLac()
        {
            return View();

        }
    }
}